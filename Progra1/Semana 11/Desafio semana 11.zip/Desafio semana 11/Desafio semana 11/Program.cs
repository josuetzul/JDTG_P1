﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Desafio_semana_11
{
    class Libro
    {
        int codigo_id, n_paginas, paginas_leidas, n_paginas_disp;
        string nombre;
        double porcentaje;
        bool disponible = true;

        //Constructor
        public Libro(int elCodigo, string elNombre, int nPaginas, int lPaginas)
        {
            codigo_id = elCodigo;
            n_paginas = nPaginas;
            nombre = elNombre;
            paginas_leidas = lPaginas;
        }

        public int Leer()
        {
            if (paginas_leidas > n_paginas)
            {
                Console.WriteLine("Error, ingresó más paginas de las que hay disponibles");
                Console.ReadKey();
                Console.Clear();
                Environment.Exit(0);
            }
            else if (paginas_leidas == n_paginas)
            {
                disponible = false;
            }
            n_paginas_disp = n_paginas - paginas_leidas;
            paginas_leidas = paginas_leidas + 0;
            return (paginas_leidas);
        }

        public double Porcentaje()
        {
            porcentaje = (paginas_leidas * 100) / n_paginas;
            return porcentaje;
        }

        public int ObtenerPagActual()
        {
            return paginas_leidas;
        }

        public string MostrarLibro()
        {
            string mostrar_libro = $"El código del libro es: {codigo_id} \nEl nombre del libro es: {nombre}" +
                $" \nLa cantidad de páginas totales son: {n_paginas} \nEl porcentaje de lectura es: {porcentaje}%" +
                $"\nLa cantidad de páginas leídas son: {paginas_leidas}";
            Console.WriteLine(mostrar_libro);
            return mostrar_libro;
        }

        public bool Estado()
        {
            if (disponible)
            {
                Console.WriteLine("El estado del libro es en proceso");
            }
            if (disponible && paginas_leidas == 0)
            {
                Console.WriteLine("El estado del libro es no leído");
            }
            else if (!disponible)
            {
                Console.WriteLine("El libro ya está leído completamente");
            }
            return true;
        }

        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    int id = 078125;
                    int num_paginas = 231;
                    string name = "Cada dia es viernes";
                    Console.Write("Ingrese la cantidad de páginas leídas: ");
                    int num_pag_leidas = Convert.ToInt32(Console.ReadLine());

                    Libro libro = new Libro(id, name, num_paginas, num_pag_leidas);

                    libro.Leer();
                    libro.Porcentaje();
                    libro.ObtenerPagActual();
                    libro.MostrarLibro();
                    libro.Estado();

                    Console.ReadKey();
                    Console.Clear();
                }
                catch
                {
                    Console.WriteLine("\nIngrese un número válido");
                    Console.ReadKey();
                }
            }
        }
    }
}
