﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_pelicula
{
    public class Pelicula
    {
        string nombre, genero;
        int año;
        int duracion_min, duracion_horas;
        bool epica;
        double valoracion;

        //constructor
        public Pelicula(string elNombre, int laDuracion, string elGenero, int elAño, double laValoracion)
        {
            nombre = elNombre;
            duracion_min = laDuracion;
            genero = elGenero;
            año = elAño;
            valoracion = laValoracion;
            duracion_horas = duracion_min / 60;
            if (duracion_horas >= 3)
            {
                epica = true;
            }
            else
            {
                epica = false;
            }
        }

        public void Imprimir()
        {
            string cadena = $"Nombre: {nombre} \nDuración: {duracion_min} minutos \nGénero: {genero} \nAño de estreno: {año}";
            Console.WriteLine(cadena);
        }

        public void esPeliculaEpica()
        {
            if (epica)
            {
                string epicidad = "Es épica";
                Console.WriteLine(epicidad);
            }
        }

        public void Valoracion()
        {
            if (valoracion == 0 && valoracion <= 2)
            {
                string cadena_valo = "Muy Mala";
                Console.WriteLine("La valoración de la película es: " + cadena_valo);
            }
            else if (valoracion > 2 && valoracion <= 5)
            {
                string cadena_valo = "Mala";
                Console.WriteLine("La valoración de la película es: " + cadena_valo);
            }
            else if (valoracion > 5 && valoracion <= 7)
            {
                string cadena_valo = "Regular";
                Console.WriteLine("La valoración de la película es: " + cadena_valo);
            }
            else if (valoracion > 7 && valoracion <= 8)
            {
                string cadena_valo = "Buena";
                Console.WriteLine("La valoración de la película es: " + cadena_valo);
            }
            else if (valoracion > 8 && valoracion <= 10)
            {
                string cadena_valo = "Excelente";
                Console.WriteLine("La valoración de la película es: " + cadena_valo);
            }
            else
            {
                Console.WriteLine("Ingrese una valoración válida");
            }
        }

        public static bool operator ==(Pelicula p1, Pelicula p2)
        {

            return p1.Equals(p2);
        }
        public static bool operator !=(Pelicula p1, Pelicula p2)
        {
            return !(p1 == p2);
        }

        static void Main(string[] args)
        {
            /* Console.Write("Ingrese el nombre de la película: ");
             string name = Console.ReadLine();
             Console.Write("\nIngrese la duración de la película en minutos: ");
             int duration = Convert.ToInt32(Console.ReadLine());
             Console.Write("\nIngrese el género de la película: ");
             string genre = Console.ReadLine();
             Console.Write("\nIngrese el año de la película: ");
             int year = Convert.ToInt32(Console.ReadLine());
             Console.WriteLine("\nIngrese la valoración de la película: ");
             double valoration = Convert.ToDouble(Console.ReadLine()); */

            string name = "Gandhi";
            int duration = 191;
            string genre = "DRAMA";
            int year = 1982;
            double valoration = 8.1;

            Pelicula pelicula1 = new Pelicula(name, duration, genre, year, valoration);

            pelicula1.Imprimir();
            pelicula1.esPeliculaEpica();
            pelicula1.Valoracion();
            Console.WriteLine("\nPresione enter para la segunda película\n");
            Console.ReadKey();

            /* Console.Write("Ingrese el nombre de la película: ");
             name = Console.ReadLine();
             Console.Write("\nIngrese la duración de la película en minutos: ");
             duration = Convert.ToInt32(Console.ReadLine());
             Console.Write("\nIngrese el género de la película: ");
             genre = Console.ReadLine();
             Console.Write("\nIngrese el año de la película: ");
             year = Convert.ToInt32(Console.ReadLine());
             Console.WriteLine("\nIngrese la valoración de la película: ");
             double valoration2 = Convert.ToDouble(Console.ReadLine()); */

            name = "Thor";
            duration = 115;
            genre = "ACCION";
            year = 2011;
            valoration = 7.0;

            Pelicula pelicula2 = new Pelicula(name, duration, genre, year, valoration);

            pelicula2.Imprimir();
            pelicula2.esPeliculaEpica();
            pelicula2.Valoracion();

            bool sonSimilares = pelicula1.Equals(pelicula2);
            if (sonSimilares)
            {
                Console.WriteLine("\nLas películas son similares.");
            }
            else { Console.WriteLine("\nLas películas no son similares"); }

            Console.ReadKey();
        }

        public override bool Equals(object obj)
        {
            return obj is Pelicula pelicula &&
                   genero == pelicula.genero;
        }

        public override int GetHashCode()
        {
            return 1511702915 + EqualityComparer<string>.Default.GetHashCode(genero);
        }
    }
}
