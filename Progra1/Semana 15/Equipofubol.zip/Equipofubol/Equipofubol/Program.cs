﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace Equipofubol
{
    internal class Program
        // ALLAN Cabrera 1209023 y Josué Tzul 1067123
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Ingrese el número de equipos");
            int e=Convert.ToInt32(Console.ReadLine());
            string[,] a = new string[e, 8];
             int g =0;
            string j ="";
            for (int i = 0; i < e ;i++)
            {
                for (int cc=0; cc < 1; cc++)
                {
                    Console.WriteLine("Ingrese el nombre de los equipos No."+cc);
                    a[i,cc]=Console.ReadLine();
                }
            }
            Random nume = new Random();
            

            for (int i = 0; i < e; i++)
            {
                for (int cc = 1; cc < 7; cc++)
                {
                    g = nume.Next(1, 15);
                    j = g.ToString();
                    a[i, cc] = j;

                }
                Console.WriteLine("");
            }
            
           for (int i = 0; i < e; i++)
            {
                for (int cc = 0; cc < 7; cc++)
                {
                    Console.Write(a[i,cc]+" ");
                }
                Console.WriteLine("");
            }
           for (int filas = 0; filas < e;filas++)
            {
                for (int col = 1; col < 7; col++) { }
            }
            Console.ReadKey();
            
        }
    }
}
