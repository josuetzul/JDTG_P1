﻿using System; // Josué Tzul 1067123 y Daniel del Cid 1009823

class program
{
	static void Main(string[] args)
	{
		int n;
		int suma = 0;
		int suma2;
        int ciclos = 0;
        int prom;
		char respuesta = 's'; // s = si, n = no

		while (respuesta == 's')
		{
            Console.WriteLine("Ingrese un número");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("El valor ingresado es: " +n);

            suma = suma + n;
            Console.WriteLine("La suma es: " + suma);

            Console.WriteLine("Desea ingresar otro valor? s = si, n = no");
			respuesta = Convert.ToChar(Console.ReadLine());

            ciclos++;
        }

        prom = suma / ciclos;
        Console.WriteLine("El promedio es: " + prom);
        Console.WriteLine("Gracias");
    }
}
