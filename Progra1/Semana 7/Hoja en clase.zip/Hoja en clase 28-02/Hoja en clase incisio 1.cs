﻿using System // Josué Tzul 1067123 y Daniel del Cid 1009823

class program
{
    static void Main(string[] args)
    {
        int x = 1;
        int y = 0;
        int n;
        Console.WriteLine("Ingrese un valor positivo");
        n = Convert.ToInt32(Console.ReadLine());


        while (y < n)
        {
            Console.WriteLine(+x);
            x++;
            y++;
        }
        Console.WriteLine("Ingrese un valor válido");
    }
}