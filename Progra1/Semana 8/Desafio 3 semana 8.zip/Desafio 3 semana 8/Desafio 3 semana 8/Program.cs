﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio_3_semana_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cent = 0, cent1 = 0, cent5 = 0, cent10 = 0, cent25 = 0, cent50 = 0, total = 0;
            int quetzales = 0, Q1 = 0, Q5 = 0, Q10 = 0, Q20 = 0, Q50 = 0, Q100 = 0, Q200 = 0;
            bool valid;
            Console.WriteLine("Ingrese las fichas de 1 centavo \n");
            valid = double.TryParse(Console.ReadLine(), out cent);
            cent1 = cent * 0.01;

            for (int i = 5; i <= 10; i =i +5)
            {
                Console.WriteLine("Ingrese las fichas de " +i +" centavos \n");
                valid = double.TryParse(Console.ReadLine(), out cent);
                if (valid)
                {
                    if (i == 5)
                    {
                        cent5 = cent * 0.05;
                    }
                    if (i == 10)
                    {
                        cent10 = cent * 0.1;
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un NÚMERO");
                }
            }
            for (int i = 25; i <= 50; i = i * 2)
            {
                Console.WriteLine("Ingrese las fichas de " + i + " centavos: \n");
                valid = double.TryParse(Console.ReadLine(), out cent);
                if (valid)
                {
                    if (i == 25)
                    {
                        cent25 = cent * 0.25;
                    }
                    if (i == 50)
                    {
                        cent50 = cent * 0.50;
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un NÚMERO");
                }
            }
            Console.WriteLine("Ingrese los billetes de: 1 \n");
            valid = int.TryParse(Console.ReadLine(), out quetzales);
            if (valid)
            {
                Q1 = quetzales * 1;
            }
            for (int i = 5; i <= 20; i = i * 2)
            {
                Console.WriteLine("Ingrese los billetes de: " + i + "\n");
                valid = int.TryParse(Console.ReadLine(), out quetzales);
                if (valid)
                {
                    if (i == 5)
                    {
                        Q5 = quetzales * 5;
                    }
                    if (i == 10)
                    {
                        Q10 = quetzales * 10;
                    }
                    if (i == 20)
                    {
                        Q20 = quetzales * 20;
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un NÚMERO");
                }
            }
            for (int i = 50; i <= 200; i = i * 2)
            {
                Console.WriteLine("Ingrese los billetes de: " + i + "\n");
                valid = int.TryParse(Console.ReadLine(), out quetzales);
                if (valid)
                {
                    if (i == 50)
                    {
                        Q50 = quetzales * 50;
                    }
                    if (i == 100)
                    {
                        Q100 = quetzales * 100;
                    }
                    if (i == 200)
                    {
                        Q200 = quetzales * 200;
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un NÚMERO");
                }
            }
            total = cent1 + cent5 + cent10 + cent25 + cent50 + Q1 + Q5 + Q10 + Q20 + Q50 + Q100 + Q200;
            Console.WriteLine("El total de la caja registradora es: " + total);
            Console.ReadKey();
        }
    }
}
